@extends('admin.layout.master')    
@section('main_content')

<style type="text/css">
    #map {
  height: 30%;
  /*width: 100%;*/
}
html, body {
  height: 100%;
  width: 100%;
  margin: 0;
  padding: 0;
}
<style type="text/css">
    .form-inline .form-control {display: block;}
    .form_txt{color:#65cea7}
</style>
<!--body wrapper start-->
<div class="wrapper">
    <div class="row">
        <div class="col-sm-12">
            @include('admin.layout.breadcrumb')
            <section class="panel">
                <header class="panel-heading">
                    {{$module_title or  '' }}
                </header>
                <div class="panel-body">
                    @include('admin.layout._operation_status')
                   <!-- {{$i=0}} -->
                   <!--{{$total_amount=0}}-->
                <div class="panel-body">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3"> 
                        <header class="panel-heading">
                            Transaction History    
                        </header>
                        <div class="table-responsive">
                            <div class="panel-body">
                                <table class="table table-bordered  table-hover">
                                    <thead>
                                        <tr align="center">
                                            <th>Transaction No.</th>
                                            <th>Amount</th>
                                            <th>Transcation Date</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($arr_history as $key =>$value)
                                        <tr>
                                        
                                            <td align="center">@if (@isset ($value['id'])){{$value['id']}} @endif</td>
                                            
                                            <td>
                                                @if (@isset ($value['amount'])){{$value['amount']}} @endif
                                            </td>
                                            <td>
                                                @if (@isset ($value['created_at'])){{$value['created_at']=date("d-m-Y")}} @endif
                                            </td>
                                        
                                
                                        </tr>
                                        <!--{{ $i+=1 }}--> 
                                        <!--{{$total_amount=$total_amount+$value['amount']}}--> 
                                        @endforeach

                                    </tbody>
                                </table>
                            </div>
                            <div class="form-group">
                            <div class="col-sm-6 text-right">
                                <label><b>Total Amount</b>={{$total_amount}}</label>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-3 text-right">
                                <a href="{{ $module_url_path or 'NA' }}" class="btn btn-primary">Back</a>
                            </div>
                        </div>
                        </div>
                    </div>

            </section>
        </div>
    </div>
</div>


@endsection